//Thanks for your support in the creation of Alfred_Md-V1
//Special thanks to
// dimzdammy
//ayslayer
//stormz
// my loving girlfriend 
//Pls donate to our project 
//acc 9126325901 palmpay
//Thank you for using Alfred_Md-V1
